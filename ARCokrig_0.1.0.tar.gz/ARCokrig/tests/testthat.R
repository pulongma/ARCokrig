library(testthat)
library(ARCokrig)

test_check("ARCokrig")
